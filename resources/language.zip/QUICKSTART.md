# 🚀 QUICK START GUIDE

## Fastest Way to Run

### Windows Users
1. Double-click `run.bat`
2. Wait for installation to complete
3. Browser will open automatically at http://localhost:5000

### macOS/Linux Users
1. Open Terminal in this folder
2. Run: `./run.sh`
3. Open browser to http://localhost:5000

## Manual Start (All Platforms)

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the app
python app.py

# 3. Open browser
# Navigate to: http://localhost:5000
```

## First Time Use

1. **Enter Text**: Type or paste any text in the input field
2. **Translate**: Click "TRANSLATE ALL" or press Ctrl/Cmd + Enter
3. **Switch Theme**: Click the theme button (top right) to toggle between Hacker and Light modes
4. **Detect Language**: Click "DETECT LANGUAGE" to identify the input language

## Keyboard Shortcuts
- `Ctrl/Cmd + Enter` → Translate
- `Ctrl/Cmd + K` → Clear
- `Ctrl/Cmd + D` → Detect Language
- `Ctrl/Cmd + Shift + T` → Toggle Theme

## Troubleshooting

**Problem**: Port 5000 is in use
**Solution**: Edit `app.py` and change the port:
```python
app.run(debug=True, host='0.0.0.0', port=5001)
```

**Problem**: Translation fails
**Solution**: Check your internet connection and wait a few seconds before retrying

**Problem**: Dependencies won't install
**Solution**: 
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

## Need Help?
- Read the full README.md for detailed documentation
- Check the Features section for all capabilities
- Review API Endpoints section for developer information

---
**Enjoy translating! 🌐**
