# 🌐 PolyGlot Terminal - Universal Language Translator

A powerful, feature-rich web application built with Flask that translates text across 10 languages with dual theme support (Hacker & Light mode).

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Flask](https://img.shields.io/badge/Flask-3.0.0-green.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)

## ✨ Features

### 🎯 Core Features
- **10 Language Support**: English, Hindi, Spanish, French, German, Chinese, Japanese, Arabic, Russian, Portuguese
- **Real-time Translation**: Instant translation across all languages simultaneously
- **Language Detection**: AI-powered language detection with confidence scores
- **Dual Theme System**:
  - 🟢 **Hacker Mode**: Matrix rain effect, neon green terminal aesthetics
  - ☀️ **Light Mode**: Clean, modern, professional design

### 🚀 Advanced Features
- **Copy Functionality**: Copy individual translations or all at once
- **Character Counter**: Real-time character count tracking
- **Auto-save**: Your input is automatically saved to local storage
- **Keyboard Shortcuts**:
  - `Ctrl/Cmd + Enter`: Translate
  - `Ctrl/Cmd + K`: Clear input
  - `Ctrl/Cmd + D`: Detect language
  - `Ctrl/Cmd + Shift + T`: Toggle theme
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile
- **Smooth Animations**: Beautiful transitions and loading states
- **Status Indicators**: Real-time system status and detection feedback

### 🎨 Design Features
- Matrix rain effect in hacker mode
- Glitch effect on hover
- Smooth theme transitions
- Staggered card animations
- Custom notification system
- Professional typography with Orbitron and JetBrains Mono fonts

## 📋 Prerequisites

- Python 3.8 or higher
- pip (Python package manager)
- Modern web browser (Chrome, Firefox, Safari, Edge)

## 🔧 Installation

### 1. Clone or Download the Project

```bash
# If using git
git clone <repository-url>
cd polyglot-terminal

# Or download and extract the ZIP file
```

### 2. Create Virtual Environment (Recommended)

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the Application

```bash
python app.py
```

The application will start on `http://localhost:5000`

## 🎮 Usage Guide

### Basic Translation
1. Open your browser and navigate to `http://localhost:5000`
2. Enter text in the input field
3. Click **"TRANSLATE ALL"** button or press `Ctrl/Cmd + Enter`
4. View translations for all 10 languages in beautiful cards

### Language Detection
1. Enter text in the input field
2. Click **"DETECT LANGUAGE"** button or press `Ctrl/Cmd + D`
3. See the detected language with confidence percentage in the status bar

### Copy Translations
- **Single Translation**: Click the "COPY" button on any translation card
- **All Translations**: Click "COPY ALL" button at the top of results

### Theme Switching
- Click the theme toggle button in the top-right corner
- Or press `Ctrl/Cmd + Shift + T`
- Theme preference is saved automatically

### Keyboard Shortcuts
| Shortcut | Action |
|----------|--------|
| `Ctrl/Cmd + Enter` | Translate all |
| `Ctrl/Cmd + K` | Clear input |
| `Ctrl/Cmd + D` | Detect language |
| `Ctrl/Cmd + Shift + T` | Toggle theme |

## 📁 Project Structure

```
polyglot-terminal/
│
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── README.md              # This file
│
├── templates/
│   └── index.html         # Main HTML template
│
└── static/
    ├── css/
    │   └── styles.css     # All styling (dual themes)
    └── js/
        └── script.js      # Frontend functionality
```

## 🛠️ Technology Stack

### Backend
- **Flask 3.0.0**: Python web framework
- **googletrans 4.0.0rc1**: Translation API wrapper
- **Python 3.8+**: Programming language

### Frontend
- **HTML5**: Structure
- **CSS3**: Styling with CSS Variables
- **Vanilla JavaScript**: Interactivity
- **Canvas API**: Matrix rain effect

### Fonts
- **Orbitron**: Futuristic titles
- **JetBrains Mono**: Code-style text
- **Space Mono**: Monospace alternative

## 🎨 Themes

### Hacker Theme
- Dark background with neon green accents
- Matrix rain effect
- Terminal-style interface
- Glowing borders and shadows
- Cyberpunk aesthetics

### Light Theme
- Clean white background
- Professional blue accents
- Modern card design
- Soft shadows
- Business-friendly appearance

## 🌍 Supported Languages

| Language | Code | Flag |
|----------|------|------|
| English | en | 🇬🇧 |
| Hindi | hi | 🇮🇳 |
| Spanish | es | 🇪🇸 |
| French | fr | 🇫🇷 |
| German | de | 🇩🇪 |
| Chinese | zh-cn | 🇨🇳 |
| Japanese | ja | 🇯🇵 |
| Arabic | ar | 🇸🇦 |
| Russian | ru | 🇷🇺 |
| Portuguese | pt | 🇵🇹 |

## 🔍 API Endpoints

### POST `/translate`
Translates text to all supported languages.

**Request:**
```json
{
  "text": "Hello, world!"
}
```

**Response:**
```json
{
  "translations": {
    "hi": {
      "name": "Hindi",
      "text": "नमस्ते दुनिया!"
    },
    "es": {
      "name": "Spanish",
      "text": "¡Hola Mundo!"
    }
    // ... other languages
  }
}
```

### POST `/detect`
Detects the language of the input text.

**Request:**
```json
{
  "text": "Bonjour le monde"
}
```

**Response:**
```json
{
  "language": "French",
  "code": "fr",
  "confidence": 0.99
}
```

## 🐛 Troubleshooting

### Issue: Translation fails
**Solution**: The googletrans library may have rate limiting. Wait a few seconds and try again.

### Issue: Matrix effect not showing
**Solution**: Make sure you're in Hacker theme mode. The effect only appears in Hacker theme.

### Issue: Port already in use
**Solution**: Change the port in `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=5001)
```

### Issue: Dependencies installation fails
**Solution**: Try upgrading pip first:
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

## 🚀 Performance Tips

1. **Browser**: Use Chrome or Firefox for best performance
2. **Network**: Ensure stable internet connection for API calls
3. **Cache**: The app uses localStorage for theme and input persistence
4. **Mobile**: Works great on mobile, but desktop provides best experience

## 🔒 Security Notes

- This app runs locally by default
- No data is stored on servers
- All translations go through Google Translate API
- Theme preference stored in browser localStorage only

## 📱 Browser Compatibility

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Opera 76+

## 🎯 Future Enhancements

- [ ] Add more languages
- [ ] Text-to-speech functionality
- [ ] Translation history
- [ ] Export translations to PDF/DOCX
- [ ] User accounts and saved translations
- [ ] Offline mode with cached translations
- [ ] Voice input support
- [ ] Custom theme creation

## 📝 License

This project is open source and available under the MIT License.

## 👨‍💻 Development

### Running in Debug Mode
Debug mode is enabled by default. To disable:
```python
app.run(debug=False, host='0.0.0.0', port=5000)
```

### Adding New Languages
Edit the `LANGUAGES` dictionary in `app.py`:
```python
LANGUAGES = {
    'en': 'English',
    'new_code': 'New Language',
    # ...
}
```

## 🤝 Contributing

Contributions, issues, and feature requests are welcome!

## 📧 Support

If you encounter any issues or have questions, please check the troubleshooting section above.

## 🌟 Acknowledgments

- Google Translate API for translation services
- Flask framework for Python web development
- Matrix effect inspiration from classic hacker aesthetics
- Modern UI/UX design principles

---

**Made with ❤️ using Flask and Python**

Enjoy translating in style! 🚀🌐
