// ==================== GLOBAL VARIABLES ====================
const inputText = document.getElementById('inputText');
const translateBtn = document.getElementById('translateBtn');
const detectBtn = document.getElementById('detectBtn');
const clearBtn = document.getElementById('clearBtn');
const copyAllBtn = document.getElementById('copyAllBtn');
const charCount = document.getElementById('charCount');
const loading = document.getElementById('loading');
const resultsSection = document.getElementById('resultsSection');
const resultsGrid = document.getElementById('resultsGrid');
const notification = document.getElementById('notification');
const detectedLang = document.getElementById('detectedLang');
const themeToggle = document.getElementById('themeToggle');
const matrixCanvas = document.getElementById('matrixCanvas');

// ==================== THEME MANAGEMENT ====================
let currentTheme = localStorage.getItem('theme') || 'hacker';

function initTheme() {
    document.body.className = `${currentTheme}-theme`;
    if (currentTheme === 'hacker') {
        initMatrix();
    }
}

function toggleTheme() {
    currentTheme = currentTheme === 'hacker' ? 'light' : 'hacker';
    document.body.className = `${currentTheme}-theme`;
    localStorage.setItem('theme', currentTheme);
    
    if (currentTheme === 'hacker') {
        initMatrix();
    }
    
    showNotification(`Switched to ${currentTheme === 'hacker' ? 'Hacker' : 'Light'} mode`);
}

themeToggle.addEventListener('click', toggleTheme);

// ==================== MATRIX RAIN EFFECT ====================
let matrix;

function initMatrix() {
    const ctx = matrixCanvas.getContext('2d');
    matrixCanvas.width = window.innerWidth;
    matrixCanvas.height = window.innerHeight;

    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*()_+-=[]{}|;:,.<>?';
    const fontSize = 14;
    const columns = matrixCanvas.width / fontSize;
    const drops = [];

    for (let i = 0; i < columns; i++) {
        drops[i] = Math.random() * -100;
    }

    function draw() {
        ctx.fillStyle = 'rgba(10, 14, 26, 0.05)';
        ctx.fillRect(0, 0, matrixCanvas.width, matrixCanvas.height);

        ctx.fillStyle = '#00ff41';
        ctx.font = fontSize + 'px monospace';

        for (let i = 0; i < drops.length; i++) {
            const text = chars.charAt(Math.floor(Math.random() * chars.length));
            ctx.fillText(text, i * fontSize, drops[i] * fontSize);

            if (drops[i] * fontSize > matrixCanvas.height && Math.random() > 0.975) {
                drops[i] = 0;
            }
            drops[i]++;
        }
    }

    if (matrix) {
        clearInterval(matrix);
    }
    
    matrix = setInterval(draw, 35);
}

window.addEventListener('resize', () => {
    if (currentTheme === 'hacker') {
        initMatrix();
    }
});

// ==================== CHARACTER COUNTER ====================
inputText.addEventListener('input', () => {
    const count = inputText.value.length;
    charCount.textContent = count;
    
    // Hide results when user starts typing again
    if (count === 0) {
        resultsSection.classList.add('hidden');
    }
});

// ==================== CLEAR BUTTON ====================
clearBtn.addEventListener('click', () => {
    inputText.value = '';
    charCount.textContent = '0';
    resultsSection.classList.add('hidden');
    detectedLang.innerHTML = '<span class="icon">🌐</span> DETECTION: STANDBY';
    inputText.focus();
    showNotification('Input cleared');
});

// ==================== LANGUAGE DETECTION ====================
detectBtn.addEventListener('click', async () => {
    const text = inputText.value.trim();
    
    if (!text) {
        showNotification('Please enter some text first', 'error');
        return;
    }
    
    detectBtn.disabled = true;
    detectBtn.innerHTML = '<span class="icon">🔄</span> DETECTING...';
    
    try {
        const response = await fetch('/detect', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ text: text })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            const confidence = Math.round(data.confidence * 100);
            detectedLang.innerHTML = `<span class="icon">🌐</span> DETECTED: ${data.language} (${confidence}%)`;
            showNotification(`Detected: ${data.language} with ${confidence}% confidence`);
        } else {
            throw new Error(data.error || 'Detection failed');
        }
    } catch (error) {
        console.error('Detection error:', error);
        showNotification('Language detection failed', 'error');
        detectedLang.innerHTML = '<span class="icon">🌐</span> DETECTION: ERROR';
    } finally {
        detectBtn.disabled = false;
        detectBtn.innerHTML = '<span class="icon">🔍</span> DETECT LANGUAGE';
    }
});

// ==================== TRANSLATION ====================
translateBtn.addEventListener('click', async () => {
    const text = inputText.value.trim();
    
    if (!text) {
        showNotification('Please enter some text to translate', 'error');
        inputText.focus();
        return;
    }
    
    // Show loading
    loading.classList.remove('hidden');
    resultsSection.classList.add('hidden');
    translateBtn.disabled = true;
    translateBtn.innerHTML = '<span class="icon">⚡</span> TRANSLATING...';
    
    try {
        const response = await fetch('/translate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ text: text })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            displayResults(data.translations);
            showNotification('Translation complete!');
        } else {
            throw new Error(data.error || 'Translation failed');
        }
    } catch (error) {
        console.error('Translation error:', error);
        showNotification('Translation failed. Please try again.', 'error');
    } finally {
        loading.classList.add('hidden');
        translateBtn.disabled = false;
        translateBtn.innerHTML = '<span class="icon">⚡</span> TRANSLATE ALL';
    }
});

// ==================== DISPLAY RESULTS ====================
function displayResults(translations) {
    resultsGrid.innerHTML = '';
    
    Object.entries(translations).forEach(([code, data]) => {
        const card = createTranslationCard(code, data);
        resultsGrid.appendChild(card);
    });
    
    resultsSection.classList.remove('hidden');
    
    // Smooth scroll to results
    setTimeout(() => {
        resultsSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 100);
}

// ==================== CREATE TRANSLATION CARD ====================
function createTranslationCard(code, data) {
    const card = document.createElement('div');
    card.className = 'translation-card';
    
    const flagEmojis = {
        'en': '🇬🇧',
        'hi': '🇮🇳',
        'es': '🇪🇸',
        'fr': '🇫🇷',
        'de': '🇩🇪',
        'zh-cn': '🇨🇳',
        'ja': '🇯🇵',
        'ar': '🇸🇦',
        'ru': '🇷🇺',
        'pt': '🇵🇹'
    };
    
    card.innerHTML = `
        <div class="card-header">
            <div class="lang-name">
                ${flagEmojis[code] || '🌐'} ${data.name.toUpperCase()}
            </div>
            <button class="copy-btn" onclick="copyText('${code}', this)">
                📋 COPY
            </button>
        </div>
        <div class="translation-text" id="text-${code}">
            ${escapeHtml(data.text)}
        </div>
    `;
    
    return card;
}

// ==================== COPY FUNCTIONALITY ====================
function copyText(code, button) {
    const textElement = document.getElementById(`text-${code}`);
    const text = textElement.textContent;
    
    navigator.clipboard.writeText(text).then(() => {
        const originalText = button.innerHTML;
        button.innerHTML = '✓ COPIED';
        button.style.pointerEvents = 'none';
        
        setTimeout(() => {
            button.innerHTML = originalText;
            button.style.pointerEvents = 'auto';
        }, 2000);
        
        showNotification('Copied to clipboard!');
    }).catch(err => {
        console.error('Copy failed:', err);
        showNotification('Copy failed', 'error');
    });
}

// ==================== COPY ALL TRANSLATIONS ====================
copyAllBtn.addEventListener('click', () => {
    const translations = [];
    const cards = document.querySelectorAll('.translation-card');
    
    cards.forEach(card => {
        const langName = card.querySelector('.lang-name').textContent.trim();
        const text = card.querySelector('.translation-text').textContent.trim();
        translations.push(`${langName}:\n${text}\n`);
    });
    
    const allText = translations.join('\n---\n\n');
    
    navigator.clipboard.writeText(allText).then(() => {
        showNotification('All translations copied to clipboard!');
    }).catch(err => {
        console.error('Copy all failed:', err);
        showNotification('Copy failed', 'error');
    });
});

// ==================== NOTIFICATION SYSTEM ====================
function showNotification(message, type = 'success') {
    notification.textContent = message;
    notification.classList.remove('hidden');
    
    setTimeout(() => {
        notification.classList.add('hidden');
    }, 3000);
}

// ==================== UTILITY FUNCTIONS ====================
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ==================== KEYBOARD SHORTCUTS ====================
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + Enter to translate
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        translateBtn.click();
    }
    
    // Ctrl/Cmd + K to clear
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        clearBtn.click();
    }
    
    // Ctrl/Cmd + D to detect
    if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
        e.preventDefault();
        detectBtn.click();
    }
    
    // Ctrl/Cmd + Shift + T to toggle theme
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'T') {
        e.preventDefault();
        toggleTheme();
    }
});

// ==================== INITIALIZE ====================
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    inputText.focus();
    
    // Add tooltip for keyboard shortcuts
    setTimeout(() => {
        console.log('%c🚀 KEYBOARD SHORTCUTS 🚀', 'color: #00ff41; font-size: 16px; font-weight: bold;');
        console.log('%cCtrl/Cmd + Enter: Translate', 'color: #00d9ff;');
        console.log('%cCtrl/Cmd + K: Clear', 'color: #00d9ff;');
        console.log('%cCtrl/Cmd + D: Detect Language', 'color: #00d9ff;');
        console.log('%cCtrl/Cmd + Shift + T: Toggle Theme', 'color: #00d9ff;');
    }, 1000);
});

// ==================== PERFORMANCE OPTIMIZATION ====================
// Debounce function for better performance
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Auto-save input to localStorage
const saveInput = debounce(() => {
    localStorage.setItem('lastInput', inputText.value);
}, 500);

inputText.addEventListener('input', saveInput);

// Restore last input on page load
const lastInput = localStorage.getItem('lastInput');
if (lastInput) {
    inputText.value = lastInput;
    charCount.textContent = lastInput.length;
}
