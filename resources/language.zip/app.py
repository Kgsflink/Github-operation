from flask import Flask, render_template, request, jsonify
from googletrans import Translator
import os

app = Flask(__name__)
translator = Translator()

# Supported languages with their codes
LANGUAGES = {
    'en': 'English',
    'hi': 'Hindi',
    'es': 'Spanish',
    'fr': 'French',
    'de': 'German',
    'zh-cn': 'Chinese',
    'ja': 'Japanese',
    'ar': 'Arabic',
    'ru': 'Russian',
    'pt': 'Portuguese'
}

@app.route('/')
def index():
    return render_template('index.html', languages=LANGUAGES)

@app.route('/translate', methods=['POST'])
def translate():
    try:
        data = request.get_json()
        text = data.get('text', '')
        
        if not text.strip():
            return jsonify({'error': 'No text provided'}), 400
        
        translations = {}
        
        # Translate to all languages
        for lang_code, lang_name in LANGUAGES.items():
            try:
                translation = translator.translate(text, dest=lang_code)
                translations[lang_code] = {
                    'name': lang_name,
                    'text': translation.text
                }
            except Exception as e:
                translations[lang_code] = {
                    'name': lang_name,
                    'text': f'Translation error: {str(e)}'
                }
        
        return jsonify({'translations': translations})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/detect', methods=['POST'])
def detect_language():
    try:
        data = request.get_json()
        text = data.get('text', '')
        
        if not text.strip():
            return jsonify({'error': 'No text provided'}), 400
        
        detection = translator.detect(text)
        detected_lang = LANGUAGES.get(detection.lang, 'Unknown')
        
        return jsonify({
            'language': detected_lang,
            'code': detection.lang,
            'confidence': detection.confidence
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
